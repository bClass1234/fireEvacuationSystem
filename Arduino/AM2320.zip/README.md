# AM2320-master
Arduino AM2320 I2C temperature humidity
